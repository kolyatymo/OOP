#pragma once
#include "Exception.h"
using namespace std;

class Rectangle
{
public:
	Rectangle(){}

	void setLength(const size_t& wigth) {
		if (width < 0)
			throw NegativeLength();
		if (width == 0)
			throw zeroLength();
		cout << wigth << endl;
	}

	void setWigth(const size_t& wigth)
	{
		if (width < 0)
			throw NegativeWidth();
		if (width == 0)
			throw zeroWigth();
		cout << wigth << endl;
	}

	void getWigth()const {

	}

private:
	size_t width;
	size_t length;

};

