#include "fraction.h"
#include <iostream>

void Fraction::print() const
{
	std::cout << numerator << "/" << denominator;
}

void Fraction::abbreviation()
{
	if (this->numerator % 2 == 0 and this->denominator % 2 == 0)
	{
		this->numerator /= 2;
		this->denominator /= 2;
	}
}

Fraction Fraction::operator+(const Fraction& other)
{
	return Fraction(
		this->numerator * other.denominator + other.numerator * this->denominator,
		this->denominator * other.denominator);
}

Fraction Fraction::operator-(const Fraction& other)
{
	return Fraction(
		this->numerator * other.denominator - other.numerator * this->denominator,
		this->denominator * other.denominator);
}

Fraction Fraction::operator*(const Fraction& other)
{
	return Fraction(this->numerator * other.numerator, this->denominator * other.denominator);
}

Fraction Fraction::operator/(const Fraction& other)
{
	return Fraction(this->numerator * other.denominator, this->denominator * other.numerator);
}

Fraction& Fraction::operator++()
{
	this->numerator++;
	this->denominator++;
	return *this;
}

Fraction& Fraction::operator--()
{
	this->numerator--;
	this->denominator--;
	return *this;
}

bool Fraction::operator==(const Fraction& other)
{
	return this->numerator == other.numerator and this->denominator == other.denominator;
}

bool Fraction::operator!=(const Fraction& other)
{
	return !(*this == other);
}

bool Fraction::operator>(const Fraction& other)
{
	return this->numerator > other.numerator and this->denominator > other.denominator;
}

bool Fraction::operator<(const Fraction& other)
{
	return this->numerator < other.numerator and this->denominator < other.denominator;
}

void Fraction::validation()
{
	if(this->denominator == 0)
	{
		std::cout << "Error write a number greater than 0 --> ";
		std::cin >> this->denominator;
	}

	if(this->numerator < 0)
	{
		this->numerator = -numerator;
		this->denominator = -denominator;
	}
}
